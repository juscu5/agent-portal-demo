const validateToken = require('./ValidateToken');

module.exports = {
  validateToken,

};
