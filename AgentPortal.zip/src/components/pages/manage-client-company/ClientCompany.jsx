import React from "react";

const clientgeo = () => {
  return (
    <React.Fragment>
      <>
        <div></div>
      </>
    </React.Fragment>
  );
};

export default clientgeo;
