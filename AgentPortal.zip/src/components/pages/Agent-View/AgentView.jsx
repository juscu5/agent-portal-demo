import React from "react";
import "./AgentView.scss";
import OverviewCard from "../../organisms/header/OverviewCard";
import "react-responsive-carousel/lib/styles/carousel.min.css"; // requires a loader
import { Carousel } from "react-responsive-carousel";

import tp1 from "../../assets/tppicture1.png";
import tp2 from "../../assets/tppicture2.jpg";
import tp4 from "../../assets/tppicture4.jpg";

const AgentView = () => {
  return (
    <React.Fragment>
      <div className="agentView">
        <div class="carouselDiv">
          <Carousel
            useKeyboardArrows={true}
            infiniteLoop={true}
            autoPlay={true}
            showArrows={false}
            showThumbs={false}
          >
            <div>
              <img src={tp1} />
            </div>
            <div>
              <img src={tp2} />
            </div>
            <div>
              <img src={tp4} />
            </div>
          </Carousel>
        </div>

        <br />

        <div class="column">
          <h1 class="title">
            <table class="table is-fullwidth is-borderless forTitle">
              <thead>
                <tr class="forCenter">
                  <th class="titleName">Overview</th>
                </tr>
              </thead>
            </table>
          </h1>
        </div>

        <div class="columns is-multiline is-centered">
          <div class="column is-narrow">
            <OverviewCard />
          </div>
          <div class="column is-narrow">
            <OverviewCard />
          </div>
          <div class="column is-narrow">
            <OverviewCard />
          </div>
          <div class="column is-narrow">
            <OverviewCard />
          </div>
          <div class="column is-narrow">
            <OverviewCard />
          </div>
        </div>
      </div>
    </React.Fragment>
  );
};

export default AgentView;
