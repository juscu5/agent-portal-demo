import React from 'react';

const ButtonAtom = (props) => {

    return(<button {...props}/>)
}

export default ButtonAtom;