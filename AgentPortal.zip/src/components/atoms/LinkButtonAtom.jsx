import React from 'react';

const LinkButtonAtom = (props) => {

    return(<a {...props}/>)
}

export default LinkButtonAtom;