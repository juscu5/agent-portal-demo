import React from 'react';

const LabelAtom = (props) => {

    return(<label {...props}/>)
}

export default LabelAtom;