import React from 'react';

const HeaderAtom = (props) => {

    return(<h1 {...props}/>)
}

export default HeaderAtom;