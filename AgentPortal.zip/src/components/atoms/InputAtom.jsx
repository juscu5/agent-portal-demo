import React from "react";
import './Atoms.scss';

const InputAtom = (props) => {

    return(<input {...props}/>)
}

export default InputAtom;