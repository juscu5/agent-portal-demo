import React from "react";
import './Atoms.scss';

const SelectAtom = (props) => { 
    return (<select {...props}/>);
};
export default SelectAtom;