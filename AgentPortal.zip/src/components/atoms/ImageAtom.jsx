import React from 'react';

const ImageAtom = (props) => {
    return(<img {...props}/>)
}

export default ImageAtom;